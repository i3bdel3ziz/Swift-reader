//
//  StreamReader.swift
//  CourseAssignment
//
//  Created by AbdulAziz Jamal on 10/16/15.
//  Copyright © 2015 AbdulAziz Jamal. All rights reserved.
//

import Foundation

class StreamScanner
{
    let sourceLocation: String
    var lines = [String]()
    var currentLineIndex = -1
    var fileContents: String?
    
    init( sourceLocation: String )
    {
        self.sourceLocation = sourceLocation

        
        do {
            fileContents = try String(contentsOfFile: sourceLocation, encoding: NSUTF8StringEncoding)
        } catch _ as NSError {
            fileContents = nil
            return
        }
        
        lines = (fileContents?.componentsSeparatedByString("\n"))!
        
    }
    
    func readLine()->String?
    {
        if(lines.count-1>currentLineIndex)
        {
            currentLineIndex++;
            return lines[currentLineIndex]
        }
        else
        {
            return nil
        }
        
    }

}