//
//  main.swift
//  CourseAssignment
//
//  Created by AbdulAziz Jamal on 10/16/15.
//  Copyright © 2015 Abdulaziz Jamal. All rights reserved.
//

import Foundation


// Application start.
print("Starting application... \n")


    /* This can be changed to any location depending where bradford.data file is.
    In my case i copied the data file to the the Coursework1 path folder with the swift files that i've crated.
 Note : full path required for the file location. */


// Ready to test file location.
var inputFileLocation = NSString(string:"~/Desktop/MD /Coursework1/Coursework1/bradford.data").stringByExpandingTildeInPath

// Create StreamScanner.
let scanner = StreamScanner(sourceLocation: inputFileLocation)

if let input = scanner.fileContents
{
    
    let dataCollection:BradfordDataCollection = BradfordDataCollection()                                                            // Create new collection.
    var a = scanner.readLine()
    while let dataLine: String = scanner.readLine()
    {
        let data = dataLine.removeExcessiveSpaces()                         // Remove excessive spaces.
        let bradfordData:BradfordData? = parseBradfordDataLine(data)        // Parse and repackage to BradfordData struct.
        dataCollection.addData(bradfordData)                                // Add to data collection.
        
        
    }
    
    // Display results.
    dataCollection.calculateWettestYear()   // Calculate wettest year.
    dataCollection.calculateDriestYear()    // Calculate driest year.
    dataCollection.calculateSuniestMonth()  // Calculate suniest month.
    
    // Print application finish when the program execute sucessfully.
    print("\n Application finished. ")
    
    
}
else
{   // If condition of file reader failed to find the data file return file is not found.
    print("File doesn't exist ! \n")
}
