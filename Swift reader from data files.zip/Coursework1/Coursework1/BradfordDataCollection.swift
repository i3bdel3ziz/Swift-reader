//
//  BradfordDataCollection.swift
//  CourseAssignment
//
//  Created by AbdulAziz Jamal on 10/16/15.
//  Copyright © 2015 AbdulAziz Jamal. All rights reserved.
//

import Foundation


class BradfordDataCollection
{
    
    var dataCollection = [BradfordData]()                           // Data array.
    var dataByYear = [String: [BradfordData]]()                     // Data array divided by year to simplify analysis.
    
 
    func addData(data:BradfordData?)                                // Add new data.
    {
        if(data != nil)
        {
            dataCollection.append(data!)                            // Append new data.
            
            var yearData = dataByYear[String(data!.year)]           // Put in dictionary divided by year.
            if(yearData == nil)
            {
                yearData = [BradfordData]()
            }
            yearData!.append(data!)
            dataByYear[String(data!.year)] = yearData
            
        }
    }
    
    func calculateSuniestMonth()                                     // Calculates sunniest month.
    {
        
        if(dataCollection.count==0)                                  // If data collection has no data - return.
        {
            print("No data loaded")
            return
        }

        var amountOfSunshinePerMonth = [String: Double]()
        
        for (_, collection) in dataByYear
        {
            
            for data in collection {
                
                if(amountOfSunshinePerMonth[data.monthName] == nil)
                {
                    amountOfSunshinePerMonth[data.monthName] = 0;
                }
                
                amountOfSunshinePerMonth[data.monthName]! += data.numHoursSunshine
                
            }
        }

        var maxSunshineHours:Double = 0.0
        var maxSunshineMonth:String = ""
        
        for (monthName, sunshineHours) in amountOfSunshinePerMonth       // Iterate amountOfSunshinePerMonth dictionary to find the suniest month of them all.
        {
            
            if( sunshineHours > maxSunshineHours)
            {
                maxSunshineHours = sunshineHours
                maxSunshineMonth = monthName
            }
        }

        
        print("Sunniest month is \(maxSunshineMonth) with \(maxSunshineHours) hours of sunshine")
        

        
    }
    
    func calculateWettestYear()
    {
        
        if(dataCollection.count==0)                             // Calculates wettest year.
        {
            print("No data loaded")                             // If data collection has no data - return. 
            return
        }
        
        let amountOfRainfallPerYear = getAmountOfRainfallPerYear()
        
        var maxRainfall:Double = 0.0
        var maxRainfallYear:String = ""
        
        for (year, rainfallAmount) in amountOfRainfallPerYear       // iterate amountOfRainfallPerYear  dictionary to find the wettest year.
        {
            
            if( rainfallAmount > maxRainfall)
            {
                maxRainfall = rainfallAmount
                maxRainfallYear = year
            }
        }
        

        print("Wettest year is \(maxRainfallYear) with \(maxRainfall)mm of rainfall")
        
    }
    
    func calculateDriestYear()                      // Calculates driest year.
    {
        
        if(dataCollection.count==0)
        {
            print("No data loaded")
            return
        }
        let amountOfRainfallPerYear = getAmountOfRainfallPerYear()
        
        var minRainfall:Double = DBL_MAX
        var minRainfallYear:String = ""
        
        for (year, rainfallAmount) in amountOfRainfallPerYear       // Find driest year.
        {
            
            if( rainfallAmount < minRainfall)
            {
                minRainfall = rainfallAmount
                minRainfallYear = year
            }
        }

        print("Driest year is \(minRainfallYear) with \(minRainfall)mm of rainfall")
    }
    
    func getAmountOfRainfallPerYear()-> [String: Double]     // Calculate amount of rainfall for each year.
    {
        var amountOfRainfallPerYear = [String: Double]()
        
        for (year, collection) in dataByYear
        {
            
            amountOfRainfallPerYear[year] = 0;
            for data in collection {
                amountOfRainfallPerYear[year]! += data.rainfall
                
            }
        }
        
        return amountOfRainfallPerYear

    }
}
