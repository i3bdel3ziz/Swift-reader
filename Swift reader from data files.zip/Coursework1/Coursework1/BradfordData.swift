//
//  BradfordData.swift
//  CourseAssignment
//
//  Created by AbdulAziz Jamal on 10/16/15.
//  Copyright © 2015 AbdulAziz Jamal. All rights reserved.
//

import Foundation

// Define a class to load records from file and perform analysis to the records.
// Note: In Swift 2, Printable protocol is replaced by CustomStringConvertible protocol.
struct BradfordData : CustomStringConvertible
{

    /*
        Represents data line from bradford.data file.
    */
    var year:uint
    var month:uint
    var meanMaxTemp:Double
    var meanMinTemp:Double
    var frostDays:uint
    var rainfall:Double
    var numHoursSunshine:Double
    
    // Initializor.
    init(year: uint, month: uint, meanMaxTemp:Double, meanMinTemp:Double, frostDays:uint, rainfall:Double, numHoursSunshine:Double) {

        self.year = year
        self.month = month
        self.meanMaxTemp = meanMaxTemp
        self.meanMinTemp = meanMinTemp
        self.frostDays = frostDays
        self.rainfall = rainfall
        self.numHoursSunshine = numHoursSunshine
    }
    
    var monthName: String {
        get {
            return getMonthName()
        }
    }
    // Months numeric converted to string.
    func getMonthName()->String{
        switch month {
            case 1: return "January"
            case 2: return "February"
            case 3: return "March"
            case 4: return "April"
            case 5: return "May"
            case 6: return "June"
            case 7: return "July"
            case 8: return "August"
            case 9: return "September"
            case 10: return "October"
            case 11: return "November"
            case 12: return "December"
            default: return ""
        }
        
    }
    
    // Description in type string.
    var description: String {
        let string = "\(year)  \(month) \(monthName) \(meanMaxTemp) \(meanMinTemp) \(frostDays) \(rainfall) \(numHoursSunshine)"
        return string
    }
    
}