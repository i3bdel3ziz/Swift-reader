//
//  Utils.swift
//  CourseAssignment
//
//  Created by AbdulAziz Jamal on 10/16/15.
//  Copyright © 2015 AbdulAziz Jamal. All rights reserved.
//

import Foundation

extension String{
    func removeExcessiveSpaces()->String {  // Remove excessive spaces from given string.
        let components = self.componentsSeparatedByCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        let filtered = components.filter({!$0.isEmpty})
        return filtered.joinWithSeparator(" ")
    }
}

func parseBradfordDataLine(dataLine:String?)->BradfordData? // Parse line from bradford.data file and convert it to BradfordData. struct.
{
    if let values = dataLine?.componentsSeparatedByString(" ") where values.count == 7
    {
        let year:uint? = uint(values[0])
        let month:uint? = uint(values[1])
        let meanMaxTemp:Double? = Double(values[2])
        let meanMinTemp:Double? = Double(values[3])
        let frostDays:uint? = uint(values[4])
        let rainfall:Double? = Double(values[5])
        let numHoursSunshine:Double? = Double(values[6])
        
        if(year != nil && month  != nil && meanMaxTemp != nil && meanMinTemp != nil && frostDays != nil && rainfall != nil && numHoursSunshine != nil)
        {
            return BradfordData(year: year!, month: month!, meanMaxTemp: meanMaxTemp!, meanMinTemp: meanMinTemp!, frostDays: frostDays!, rainfall: rainfall!, numHoursSunshine: numHoursSunshine!)
        }
        
    }
    
    
    return nil
}








